import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class editList {

	public editList(){
		//initialize variables
		int size, sizeL, pick;
		String input;
		int done = 00;
		String finish = "finish";
		File list = new File("list.txt");
		Scanner scan = new Scanner(System.in);
		ArrayList<String> restaurant = new ArrayList<String>();
		ArrayList<Integer> choices = new ArrayList<Integer>();
		
		//show current list of restaurants
		System.out.println("Here is the current list of restaurants to pick from");
		showList sl = new showList();
		sl.showList();
		
			//populate list
			if(restaurant.isEmpty()) {
				try {
					Scanner scanList = new Scanner(list);
					//System.out.println("...begining to populate list...");
					while(scanList.hasNextLine()) {
						restaurant.add(scanList.nextLine());
					}
					scanList.close();
				}catch(IOException e) {e.printStackTrace();}
			}
			
			//ask for input
			System.out.println("Type numbers of the restaurant you want to remove\n Type 'finish' to edit the list or '00' to return to main menu.");
	
			//gets input(s) from user
			do {
				input = scan.nextLine();
				if(input.equals(finish)) {break;}
				//check if string or int
				if(isInteger(input)) {
					pick = Integer.parseInt(input);//changes string to int
					//exits editing 
					if(pick == done) {System.out.println("Finished editing"); 
						menu Menu = new menu();Menu.menu();System.out.println("out\n");}
					//check if # out of bounds
					size = restaurant.size();
					if(pick > size+1 || pick < 0) {System.out.println("Number out of bounds, try again"); break;}
					choices.add(pick);
				}else System.out.println("try again");
			}while(input!= finish);
			
			//sorts choices highest->lowest
			Collections.sort(choices, Collections.reverseOrder());
			
			//remove chosen item(s)
			sizeL = choices.size();
			for(int i=0;i<sizeL;i++) {
				//System.out.println("removing "+ restaurant.get(choices.get(i))+"...");
				pick = choices.get(i);
				if(restaurant.remove(pick) != null) {System.out.println("..deleted");}else {System.out.println("..not deleted");}
			}

			//delete old list
			if(list.exists()) {
				if(list.delete())
					System.out.println("Old List deleted...");
				else {System.out.println("List failed to be deleted");menu Menu = new menu();Menu.menu();} //goes back to menu if failed to delete list
			}else {System.out.println("...list does not exist...");}
			
			//create new list 
			System.out.println("New list being created...");
			File myObj = new File("list.txt");
		
			//attempt to create new file
			try {
				if(myObj.createNewFile()) {System.out.println("File created...");
				}else {System.out.println("File already exists...");}
			} catch (IOException e) {
				e.printStackTrace();}
		
			//populate new list
			try {
				BufferedWriter fw = new BufferedWriter(new FileWriter(list, true));
				size = restaurant.size();
				for(int i=0;i<size;i++) {
					if(!restaurant.get(i).isEmpty()) {
						if(compare(restaurant.get(i))) {
							//System.out.println(restaurant.get(i)+" is being added");
							fw.write(restaurant.get(i));//adds item to new list
							fw.newLine(); //adds new line
					}else {System.out.println("Already in list...");}
						}
				}	
			fw.close();//close file reader
			}catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			showList sL = new showList();
			sL.showList();//show current list
			menu Menu = new menu();Menu.menu();//return to main menu
		}
	/*
	 * comparing input to current list
	 * returns false if item is already present
	 */
	public boolean compare(String item) {
		int size;
		boolean isValid = true;
		String file = "list.txt";
		List<String> restaurant;
		

		try {
			FileReader fr = new FileReader(file);
			//reads all names from list.txt
			restaurant = Files.readAllLines(Paths.get(file));
			//gets # of names
			size = restaurant.size();
			
				for(int i=0;i<size;i++) {
					if(!restaurant.get(i).isEmpty()) { //if restaurant is not empty/at end
						if(restaurant.get(i).equals(item)) {
							isValid = false;
						}
					}		
					fr.close();
				}
		}catch(IOException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
		return isValid;
	}
	public static boolean isInteger(String str) {
	    if (str == null) {
	        return false;
	    }
	    int length = str.length();
	    if (length == 0) {
	        return false;
	    }
	    int i = 0;
	    if (str.charAt(0) == '-') {
	        if (length == 1) {
	            return false;
	        }
	        i = 1;
	    }
	    for (; i < length; i++) {
	        char c = str.charAt(i);
	        if (c < '0' || c > '9') {
	            return false;
	        }
	    }
	    return true;
	}
	public void editList() {
		// TODO Auto-generated method stub
		
	}
	
}
