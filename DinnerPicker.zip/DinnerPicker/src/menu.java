import java.io.File;
import java.io.IOException;
import java.util.Scanner;


/**
 * @author Lord Brebo
 *
 */
public class menu {	
	public menu(){
	Scanner sc = new Scanner(System.in);
	File list = new File("list.txt");
	int pick;
	String s=null;
	String a = "Adding new place";String b = "Finding a place to eat";String c = "Edit list";
	showMenu();//menu text
	while(sc.hasNextLine()){
		s = sc.nextLine();	
		pick = Integer.parseInt(s); //changes input into an integer
		switch(pick) {
		case 1:
			System.out.println("You choose: " + a);
			inputRest iR = new inputRest();
			iR.inputRest();
			break;			
		case 2:
			System.out.println("You choose: " + b);
			findRest fR = new findRest();
			fR.findRest();
			break;
		case 3:
			System.out.println("You choose: " + c);
			editList eL = new editList();
			eL.editList();
			break;
		case 4:
			System.out.println("Have a good day");
			System.exit(0);
			break;		
		case 5:
			System.out.println("Attemping to delete list...");
			list.delete();
			break;
		case 6:
			showList sl = new showList();
			sl.showList();		
		default: System.out.println("Invalid choice, please try again.");
		showMenu();//menu text	
		}
	}	
	sc.close();//close scanner
}
	/*
	 * shows menu choices
	 */
	public void showMenu() {
		System.out.println("\nHey guys, cant decide on where to go to eat?" + "\n" +
				"Or do you want to add in some more?");
				System.out.println();
				System.out.println("1 - Add a new place to eat");
				System.out.println("2 - Find a place to eat");
				System.out.println("3 - Edit list");
				System.out.println("4 - Exit");
				System.out.println("5 - Delete Current List");
				System.out.println("4 - Show Current List");
				System.out.println();
	
}
	public void menu() {
		// TODO Auto-generated method stub
		
	}
}