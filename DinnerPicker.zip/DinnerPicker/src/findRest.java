import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Scanner;

/**
 * 
 */

/**
 * @author Lord Brebo
 *
 */
public class findRest {

	public findRest() {
		// Variables
		String file = "list.txt";
		Scanner scan = new Scanner(System.in);
		List<String> restaurant;
		int size,pick,max,min=0;
		int x=1;
		//
		
		System.out.println("Finding restaurant...");
		try {
			FileReader fr = new FileReader(file);
			//reads all names from list.txt
			restaurant = Files.readAllLines(Paths.get(file));
			//gets # of names
			size = restaurant.size();
			max = size-1;
			//picks random number 
			pick = (int) ((int) min + (Math.random()*max));		
			System.out.println("How does "+ restaurant.get(pick) +" sound?");
			System.out.println("Type '2' to re-roll or '1' to exit");
				while(scan.nextInt()!= x) {
					pick = (int) ((int) min + (Math.random()*max));	
					System.out.println("How does "+ restaurant.get(pick) +" sound?");								
				}

			//closing file and scanners
			System.out.println("Enjoy dinner!");
			fr.close();		
			//scan.close();
		}catch(IOException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();			    
		}
		menu m = new menu(); m.menu();//back to menu
	}



	public void findRest() {
		// TODO Auto-generated method stub
		
	}

}
