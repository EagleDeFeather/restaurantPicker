

/**
 * 
 */

/**
 * @author Lord Brebo
 *
 */
public class main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//calling menu
		menu m = new menu();
		m.menu();



		

}
}