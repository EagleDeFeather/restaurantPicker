import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class showList {
	public showList(){
	int size;
	String file = "list.txt";
	List<String> restaurant;
	
	try {
		FileReader fr = new FileReader(file);
		//reads all names from list.txt
		restaurant = Files.readAllLines(Paths.get(file));
		//gets # of names
		size = restaurant.size();
		
			for(int i=0;i<size;i++) {
				if(!restaurant.get(i).isEmpty()) { //if restaurant is not empty/at end
					System.out.println(i + ". " + restaurant.get(i)); //lists each item
				}		
				fr.close();
			}
	}catch(IOException e) {
		System.out.println("An error occurred.");
		e.printStackTrace();
	}
	
}

	public void showList() {
		// TODO Auto-generated method stub
		
	}}
