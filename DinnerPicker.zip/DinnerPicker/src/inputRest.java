/**
 * adds new restaurants to list
 */
import java.util.List;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
/**
 * @author Lord Brebo
 *
 */
public class inputRest {
	public inputRest(){
		//variables
		Scanner scan = new Scanner(System.in);
		String file = "list.txt";
		String input = null;
		String done = "done";
		String exit = "exit";
		
		//reads name
		System.out.println("Enter name of restaurant below.\nYou can type 'done' go back to the main menu, or type 'exit'.");
			try {
				File myObj = new File(file);
				if(myObj.createNewFile()) {
					System.out.println("File created...");
				}else {
					System.out.println("File already exists...");
				}
				BufferedWriter fw = new BufferedWriter(new FileWriter(file, true));				
				while(scan.hasNextLine()) {	
					input = scan.nextLine();
					if(input.equals(exit)) {
						System.exit(0);
					}
					if(input.equals(done)) {
						menu m = new menu();
						m.menu();
						break;
					}
					if(compare(input)) { //compares to current list
						fw.write(input); //writes to file
						fw.newLine(); //adds new line
						System.out.println("Successfully added to list!");
					}
					else {
						System.out.println("Restaurant already in list...");
					}	
				}
				//scan.close();
				fw.close();
			}catch (IOException e) {
			      System.out.println("An error occurred.");
			      e.printStackTrace();			    
			}
	}
	
	/*
	 * comparing input to current list
	 * returns false if item is already present
	 */
	public boolean compare(String item) {
		int size;
		boolean isValid = true;
		String file = "list.txt";
		List<String> restaurant;
		

		try {
			FileReader fr = new FileReader(file);
			//reads all names from list.txt
			restaurant = Files.readAllLines(Paths.get(file));
			//gets # of names
			size = restaurant.size();
			
				for(int i=0;i<size;i++) {
					if(!restaurant.get(i).isEmpty()) { //if restaurant is not empty/at end
						if(restaurant.get(i).equals(item)) {
							isValid = false;
						}
					}		
					fr.close();
				}
		}catch(IOException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
		return isValid;
	}
	
	public void inputRest() {
		// TODO Auto-generated method stub
		
	}
}

